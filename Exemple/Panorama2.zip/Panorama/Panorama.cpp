// Imagine++ project
// Project:  Panorama
// Author:   Pascal
// Date:     2010/1/11

#include "./Imagine/Features.h"
#include <Imagine/Graphics.h>
using namespace Imagine;
using namespace std;

int main()
{
	// Charge et affiche les images
	Image<Color,2> I1, I2;
	if( ! load(I1, srcPath("image0006.jpg")) ||
        ! load(I2, srcPath("image0007.jpg")) ) {
        cerr<< "Impossible de charger les images" << endl;
        return 1;
    }
	int w = I1.width();
	openWindow(2*w, I1.height());
	display(I1,0,0);
	display(I2,w,0);

	// Trouve les points d'interet
	SIFTDetector D;
	D.setFirstOctave(0); // Pour aller plus vite au prix de moins de points
	Array<SIFTDetector::Feature> feats1 = D.run(I1);
	drawFeatures(feats1, Coords<2>(0,0));
	Array<SIFTDetector::Feature> feats2 = D.run(I2);
	drawFeatures(feats2, Coords<2>(w,0));

	// Compte les correspondances
	int nCor = 0; // Nombre de correspondances
	const double SEUIL_DISTANCE = 100.0*100.0;
	for(size_t i=0; i < feats1.size(); i++) {
		SIFTDetector::Feature f1=feats1[i];
		for(size_t j=0; j < feats2.size(); j++) {
			double d = squaredDist(f1.desc, feats2[j].desc);
			if(d < SEUIL_DISTANCE) {
				++nCor;
				break;
			}
		}
	}

	// Trouve les correspondances
	size_t* index1 = new size_t[nCor];
	size_t* index2 = new size_t[nCor];
	nCor = 0;
	for(size_t i=0; i < feats1.size(); i++) {
		SIFTDetector::Feature f1=feats1[i];
		double minDistance = SEUIL_DISTANCE;
		size_t jOpti = 0;
		for(size_t j=0; j < feats2.size(); j++) {
			double d = squaredDist(f1.desc, feats2[j].desc);
			if(d < minDistance) {
				minDistance = d;
				jOpti = j;
				break;
			}
		}
		if(minDistance < SEUIL_DISTANCE) {
			index1[nCor] = i;
			index2[nCor] = jOpti;
			++nCor;
		}
	}
	cout << "Im1: " << feats1.size() << " Im2: " << feats2.size()
		 << " nCor: " << nCor << endl;
	delete [] index1;
	delete [] index2;

	endGraphics();
	return 0;
}
